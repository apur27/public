React.render(
  React.createElement('h1', null, 'Hello world'),
  document.getElementById('divContainer')
);