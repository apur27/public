React.render(
    <h1>Hello World</h1>,
    document.getElementById('divContainer')
);