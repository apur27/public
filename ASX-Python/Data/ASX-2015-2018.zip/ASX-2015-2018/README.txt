Data were downloaded from https://www.asxhistoricaldata.com/

More information can be found on the above link

Data Format
	Comma separated Ticker, Date, Open, High, Low, Close, Volume.

